function answer_1() {
	document.getElementById("q1-answer").innerHTML = "<ul><li>D - Document</li> <li> O - Object </li> <li> M - Model </li> </ul>";
}

function answer_2() {
	document.getElementById("q2-answer").innerHTML = "<ul><li>Add or Remove existing elements and attributes. </li><li>React to events happening in a page. </li></ul>";
    
}
function answer_3() {
	document.getElementsByClassName("q34-answer")[0].innerHTML = "<ul><li>Parent node: 한 노드 바로 위에 있는 노드 </li><li>Child nodes: 바로 아래 지정된 노드</li><li>Sibling nodes: 같은 parent node인 같은 레벨에 있는 노드</li><li>Descendant nodes: 또 다른 노드 아래 레벨에 있는 일련의 노드들. </li><li>Ancestor: tree로 구성된 노드 위에 있는 일련의 노드들. </li></ul>";
    
}
function answer_4() {
	document.getElementsByClassName("q34-answer")[1].innerHTML = "<ul><li>document.getElementById(): 주어진 id에 있는 element 값을 리턴해주고 복제된 id 값은 HTML 설명에서 허용되지 않는다. </li><li>document.getElementsByClassName(): class에 속한 element들의 목록을 얻을 수 있다. </li><li>document.getElementsByName(): name에 기반된 리스트를 얻을 수 잇는데, name은 일반적으로 input 태그로 사용된다. </li><li>document.getElementsByTagName(): input 태그 이름을 가진 element의 목록을 얻을 수 있다. </li></ul>";
}

$('a').click(function () {
	$(this).text('Answer5');
});//Question 5

$('.item').click(function () {
	$(this).attr('style', 'font-size : 3em');
    
});//Question 6

$('div'+'.demo').dblclick(function () {
	$(this).attr('style','color : blue');
});//Question 7




